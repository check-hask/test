#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
行间 · 本地预览服务器
用法：python serve.py  [端口]
默认 http://localhost:8080
"""
import http.server
import socketserver
import sys
import os

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8080
os.chdir(os.path.dirname(os.path.abspath(__file__)))


class Handler(http.server.SimpleHTTPRequestHandler):
    extensions_map = {
        **http.server.SimpleHTTPRequestHandler.extensions_map,
        '.webmanifest': 'application/manifest+json',
        '.json': 'application/json',
        '.js': 'text/javascript',
        '.svg': 'image/svg+xml',
    }

    def end_headers(self):
        # Service Worker 与清单文件不缓存，便于更新
        if self.path.endswith(('sw.js', '.webmanifest')):
            self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        self.send_header('Service-Worker-Allowed', '/')
        super().end_headers()

    def log_message(self, fmt, *args):
        pass


socketserver.TCPServer.allow_reuse_address = True
with socketserver.TCPServer(('', PORT), Handler) as httpd:
    print('行间 · 本地预览已启动')
    print('  →  http://localhost:%d' % PORT)
    print('  Ctrl+C 停止')
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print('\n已停止')
